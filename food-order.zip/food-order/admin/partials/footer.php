<!-- Footer Section Starts -->
<div class="footer">
            <div class="wrapper">
                <p class="text-center">2024 All Rights Reserved, Kansha Restaurant. Developed By - <a href="#">Azhar Nabilah</a></p>
            </div>
        </div>
        <!-- Footer Section Ends -->
    </body>
</html>